from enum import Enum



class Order(Enum):
    rating = "rating"
    chapter = "chapter"
    volume = "volume"
    id = "id"

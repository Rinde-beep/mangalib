from User.schemas import User
def create_user(user: User):
    pass

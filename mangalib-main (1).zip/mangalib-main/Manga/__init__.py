from Manga.schemas import MangaAdd

__all__ = ["MangaAdd"]
